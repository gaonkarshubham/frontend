
'use strict';
const express = require('express');
const utils = require('./utils.js');
const supplychainRouter = express.Router();
const Order = require('../../contract/lib/order.js');

const STATUS_SUCCESS = 200;
const STATUS_CLIENT_ERROR = 400;
const STATUS_SERVER_ERROR = 500;

//  USER Management Errors
const USER_NOT_ENROLLED = 1000;
const INVALID_HEADER = 1001;

//  application specific errors
const SUCCESS = 0;
const ORDER_NOT_FOUND = 2000;

async function getUsernamePassword(request) {
    // check for basic auth header
    if (!request.headers.authorization || request.headers.authorization.indexOf('Basic ') === -1) {
        return new Promise().reject('Missing Authorization Header');  
    }

    // get auth credentials
    const base64Credentials = request.headers.authorization.split(' ')[1];
    const credentials = Buffer.from(base64Credentials, 'base64').toString('ascii');
    const [username, password] = credentials.split(':');

    if (!username || !password) {
        return new Promise().reject('Invalid Authentication Credentials');  
    }

    // attach username and password to request object
    request.username = username;
    request.password = password;

    return request;
}

async function submitTx(request, txName, ...args) {
    try {
        await getUsernamePassword(request);
        return utils.setUserContext(request.username, request.password).then((contract) => {
            args.unshift(txName);
            args.unshift(contract);
            return utils.submitTx.apply("unused", args)
                .then(buffer => {
                    return buffer;
                }, error => {
                    return Promise.reject(error);
                });
        }, error => {
            return Promise.reject(error);
        });
    }
    catch (error) {
        return Promise.reject(error);
    }
}

supplychainRouter.route('/orders').get(function (request, response) {
    submitTx(request, 'queryAllOrders', '')
        .then((queryOrderResponse) => {
            let orders = queryOrderResponse;
            response.status(STATUS_SUCCESS);
            response.send(orders);
        }, (error) => {
            response.status(STATUS_SERVER_ERROR);
            response.send(utils.prepareErrorResponse(error, STATUS_SERVER_ERROR,
                "There was a problem getting the list of orders."));
        });
}); 

supplychainRouter.route('/orders/:id').get(function (request, response) {
    submitTx(request, 'queryOrder', request.params.id)
        .then((queryOrderResponse) => {
            
            let order = Order.fromBuffer(queryOrderResponse);
            console.log(`order ${order.orderId} : price = ${order.price}, quantity = ${order.quantity}, producer = ${order.producerId}, consumer = ${order.retailerId}, trackingInfo = ${order.trackingInfo}, state = ${order.currentOrderState}`);
            response.status(STATUS_SUCCESS);
            response.send(order);
        }, (error) => {
            response.status(STATUS_SERVER_ERROR);
            response.send(utils.prepareErrorResponse(error, ORDER_NOT_FOUND,
                'Order id, ' + request.params.id +
                ' does not exist or the user does not have access to order details at this time.'));
        });
});

supplychainRouter.route('/orders').post(function (request, response) {
    submitTx(request, 'orderProduct', JSON.stringify(request.body))
        .then((result) => {
            
            console.log('\nProcess orderProduct transaction.');
            let order = Order.fromBuffer(result);
            console.log(`order ${order.orderId} : price = ${order.price}, quantity = ${order.quantity}, producer = ${order.producerId}, consumer = ${order.retailerId}, trackingInfo = ${order.trackingInfo}, state = ${order.currentOrderState}`);
            response.status(STATUS_SUCCESS);
            response.send(order);
        }, (error) => {
            response.status(STATUS_SERVER_ERROR);
            response.send(utils.prepareErrorResponse(error, STATUS_SERVER_ERROR,
                "There was a problem placing the order."));
        });
});


supplychainRouter.route('/order-history/:id').get(function (request, response) {
    submitTx(request, 'getOrderHistory', request.params.id)
        .then((orderHistoryResponse) => {
            console.log('\n>>>Process getOrderHistory response', orderHistoryResponse);
            response.status(STATUS_SUCCESS);
            response.send(orderHistoryResponse);
        }, (error) => {
            response.status(STATUS_SERVER_ERROR);
            response.send(utils.prepareErrorResponse(error, STATUS_SERVER_ERROR,
                "There was a problem fetching history for order, ", request.params.id));
        });
});

// Change status to ORDER_RECEIVED
supplychainRouter.route('/receive-order/:id').put(function (request, response) {
    submitTx(request, 'receiveOrder', request.params.id)
        .then((receiveOrderResponse) => {
            
            console.log('Process ReceiveOrder transaction.');
            let order = Order.fromBuffer(receiveOrderResponse);
            console.log(`order ${order.orderId} : state = ${order.currentOrderState}`);
            response.status(STATUS_SUCCESS);
            response.send(order);
        }, (error) => {
            response.status(STATUS_SERVER_ERROR);
            response.send(utils.prepareErrorResponse(error, STATUS_SERVER_ERROR,
                "There was a problem in receiving order, ", request.params.id));
        });

});

// Change status to ORDER_RECEIVED, add name of a shipper to order.
supplychainRouter.route('/assign-shipper/:id').put(function (request, response) {
    submitTx(request, 'assignShipper', request.params.id, request.query.shipperid)
        .then((assignShipperResponse) => {
            console.log('Process AssignShipper transaction.');
            let order = Order.fromBuffer(assignShipperResponse);
            console.log(`order ${order.orderId} : shipper = ${order.shipperId}, state = ${order.currentOrderState}`);
            response.status(STATUS_SUCCESS);
            response.send(order);
        }, (error) => {
            response.status(STATUS_SERVER_ERROR);
            response.send(utils.prepareErrorResponse(error, STATUS_SERVER_ERROR,
                "There was a problem in assigning shipper for order, ", request.params.id));
        });
});

// This changes the status on the order, and adds a ship id
supplychainRouter.route('/create-shipment-for-order/:id').put(function (request, response) {
    submitTx (request, 'createShipment', request.params.id, utils.getRandomNum())
      .then((createShipmentResponse) => {
          console.log('Process CreateShipment transaction.');
          let order = Order.fromBuffer(createShipmentResponse);
          console.log(`order ${order.orderId} : trackingInfo = ${order.trackingInfo}, state = ${order.currentOrderState}`);
          response.status(STATUS_SUCCESS);
          response.send(order);
      }, (error) => {
          response.status(STATUS_SERVER_ERROR);
          response.send(utils.prepareErrorResponse(error, STATUS_SERVER_ERROR,
              "There was a problem in creating shipment for order," + request.params.id));
      });
});

// This changes the status on the order
supplychainRouter.route('/transport-shipment/:id').put(function (request, response) {
    submitTx(request, 'transportShipment', request.params.id)
        .then((transportShipmentResponse) => {
            console.log('Process TransportShipment transaction.');
            let order = Order.fromBuffer(transportShipmentResponse);
            console.log(`order ${order.orderId} : state = ${order.currentOrderState}`);
            response.status(STATUS_SUCCESS);
            response.send(order);
        }, (error) => {
            response.status(STATUS_SERVER_ERROR);
            response.send(utils.prepareErrorResponse(error, STATUS_SERVER_ERROR,
                "There was a problem in initiating shipment for order," + request.params.id));
        });
});

// This changes the status on the order
supplychainRouter.route('/receive-shipment/:id').put(function (request, response) {
    submitTx(request, 'receiveShipment', request.params.id)
        .then((receiveShipmentResponse) => {
            
            console.log('Process ReceiveShipment transaction.');
            let order = Order.fromBuffer(receiveShipmentResponse);
            console.log(`order ${order.orderId} : state = ${order.currentOrderState}`);
            response.status(STATUS_SUCCESS);
            response.send(order);
        }, (error) => {
            response.status(STATUS_SERVER_ERROR);
            response.send(utils.prepareErrorResponse(error, STATUS_SERVER_ERROR,
                "There was a problem in receiving shipment for order," + request.params.id));
        });
});

// Delete designated order with id
supplychainRouter.route('/orders/:id').delete(function (request, response) {
    submitTx(request, 'deleteOrder', request.params.id)
        .then((deleteOrderResponse) => {
            
            console.log('Process DeleteOrder transaction.');
            console.log('Transaction complete.');
            response.status(STATUS_SUCCESS);
            response.send(deleteOrderResponse);
        }, (error) => {fb
            response.status(STATUS_SERVER_ERROR);
            response.send(utils.prepareErrorResponse(error, STATUS_SERVER_ERROR,
                "There was a problem in deleting order, " + request.params.id));
        });
});

supplychainRouter.route('/register-user').post(function (request, response) {
    try {
        let userId = request.body.userid;
        let userPwd = request.body.password;
        let userType = request.body.usertype;
        getUsernamePassword(request)
            .then(request => {

                utils.registerUser(userId, userPwd, userType, request.username).
                    then((result) => {
                        response.status(STATUS_SUCCESS);
                        response.send(result);
                    }, (error) => {
                        response.status(STATUS_CLIENT_ERROR);
                        response.send(utils.prepareErrorResponse(error, STATUS_CLIENT_ERROR,
                            "User, " + userId + " could not be registered. "
                            + "Verify if calling identity has admin privileges."));
                    });
            }, error => {
                response.status(STATUS_CLIENT_ERROR);
                response.send(utils.prepareErrorResponse(error, INVALID_HEADER,
                    "Invalid header;  User, " + userId + " could not be registered."));
            });
    } catch (error) {
        response.status(STATUS_SERVER_ERROR);
        response.send(utils.prepareErrorResponse(error, STATUS_SERVER_ERROR,
            "Internal server error; User, " + userId + " could not be registered."));
    }
});
supplychainRouter.route('/enroll-user/').post(function (request, response) {
    let userType = request.body.usertype;
    getUsernamePassword(request).then(request => {
        utils.enrollUser(request.username, request.password, userType).then(result => {
            response.status(STATUS_SUCCESS);
            response.send(result);
        }, error => {
            response.status(STATUS_CLIENT_ERROR);
            response.send(utils.prepareErrorResponse(error, STATUS_CLIENT_ERROR,
                "User, " + request.username + " could not be enrolled. Check that user is registered."));
        });
    }), (error => {
        response.status(STATUS_CLIENT_ERROR);
        response.send(utils.prepareErrorResponse(error, INVALID_HEADER,
            "Invalid header;  User, " + request.username + " could not be enrolled."));
    });
});
supplychainRouter.route('/is-user-enrolled/:id').get(function (request, response) {
    getUsernamePassword(request)
        .then(request => {
            let userId = request.params.id;
            utils.isUserEnrolled(userId).then(result => {
                response.status(STATUS_SUCCESS);
                response.send(result);
            }, error => {
                response.status(STATUS_CLIENT_ERROR);
                response.send(utils.prepareErrorResponse(error, STATUS_CLIENT_ERROR,
                  "Error checking enrollment for user, " + request.params.id));
            });
        }, ((error) => {
            response.status(STATUS_CLIENT_ERROR);
            response.send(utils.prepareErrorResponse(error, INVALID_HEADER,
                "Invalid header; Error checking enrollment for user, " + request.params.id));
        }));
})
//Get list of all users
supplychainRouter.route('/users').get(function (request, response) {
    getUsernamePassword(request)
        .then(request => {
            utils.getAllUsers(request.username).then((result) => {
                response.status(STATUS_SUCCESS);
                response.send(result);
            }, (error) => {
                response.status(STATUS_SERVER_ERROR);
                response.send(utils.prepareErrorResponse (error, STATUS_SERVER_ERROR,
                    "Problem getting list of users."));
            });
        }, ((error) => {
            response.status(STATUS_CLIENT_ERROR);
            response.send(utils.prepareErrorResponse(error, INVALID_HEADER,
                "Invalid header;  User, " + request.username + " could not be enrolled."));
        }));
});

supplychainRouter.route('/users/:id').get(function (request, response) {
    getUsernamePassword(request)
        .then(request => {
            utils.isUserEnrolled(request.params.id).then(result1 => {
                if (result1 == true) {
                    utils.getUser(request.params.id, request.username).then((result2) => {
                        response.status(STATUS_SUCCESS);
                        response.send(result2);
                    }, (error) => {
                        response.status(STATUS_SERVER_ERROR);
                        response.send(utils.prepareErrorResponse(error, STATUS_SERVER_ERROR,
                            "Could not get user details for user, " + request.params.id));
                    });
                } else {
                    let error = {};
                    response.status(STATUS_CLIENT_ERROR);
                    response.send(utils.prepareErrorResponse(error, USER_NOT_ENROLLED,
                        "Verify if the user is registered and enrolled."));
                }
            }, error => {
                response.status(STATUS_SERVER_ERROR);
                response.send(utils.prepareErrorResponse(error, STATUS_SERVER_ERROR,
                    "Problem checking for user enrollment."));
            });
        }, ((error) => {
            response.status(STATUS_CLIENT_ERROR);
            response.send(utils.prepareErrorResponse(error, INVALID_HEADER,
                "Invalid header;  User, " + request.params.id + " could not be enrolled."));
        }));
});

module.exports = supplychainRouter;
